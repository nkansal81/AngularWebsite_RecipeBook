import { Directive } from '@angular/core';

@Directive({
    selector: '[appDropDown]'
})

export class DropDownDirective {

}
